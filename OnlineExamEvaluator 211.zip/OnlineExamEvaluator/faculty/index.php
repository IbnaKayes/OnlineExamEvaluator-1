<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online SQL Evulator</title>

    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

    
<body>

    <div class="containter ">
        <div class="row mt-5">
            <div class="card col-8 offset-lg-2 pb-5 hero-card">
                <h4 class="display-4 text-dark mt-5 mx-5"><center>Welcome To</center></h4>
                <h1 class="display-2 text-success d-flex justify-content-center">Online SQL Evaluator</h1>
                <h5 class="text-dark d-flex justify-content-center">You're joining as.....</h5>

                </br>
                <a class="btn btn-outline-dark col-2 offset-lg-5" href="faculty_login.php" role="button">Faculty</a>
                </br>                
            </div>

        </div>
    </div>

</body>

</html>