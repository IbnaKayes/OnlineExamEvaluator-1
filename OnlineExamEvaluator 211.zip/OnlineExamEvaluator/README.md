# OnlineExamEvaluator
 Online Exam Evaluator is a learning management system where teachers can create examinations and students can attend the exam.
